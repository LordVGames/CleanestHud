## 0.10.0

Item highlights being survivor colored now use a better method
- Should be more performant at high item counts so the config option for this is now on by default.

Changed item highlight texture to a cleaner one

Tweaked the TAB inventory menu item displays
- Item icons are more spaced out (they're super cramped in vanilla at high item counts)
- Item icons display should take up more height in a player's inventories menu section

Fixed an extra background detail for the item icon in the inspect not being removed
- Only noticed it recently as the color difference for this detail and the rest of the inspect panel is *very* slight

Centered player names on the inventory menu

Made HP bar text smoother

Changed "Lv: ##" text to "Level ##"

Fixed NRE when opening inventories menu when someone had no items

Fixed consistent difficulty bar coloring not working past the start of "HAHAHAHA"

## 0.9.0

First release
- Not everything is finished though