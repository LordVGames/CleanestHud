## 0.10.0
Changed item highlight texture to a cleaner one

Item highlights being survivor colored now use a better method.
- Should be more performant at high item counts, if you still notice any lag while this is enabled let me know.
- The config option for this now defaults to "true".

Centered player names on the inventory menu

Changed "Lv: ##" text to "Level ##"

Made HP bar text smoother

## 0.9.0

First release
- Not everything is finished though